(function(){
  if (location.pathname !== "/") history.replaceState(null, "", "/" + location.search + location.hash);
  var popup = !/[?&]tab=1/.test(location.search) && window.outerWidth < 500;
  if (popup) document.documentElement.classList.add("hm-ext-popup");
  window.addEventListener("load", function(){
    if (!popup) return;
    setTimeout(function(){
      var b = document.createElement("button");
      b.textContent = "Open in tab \u2197";
      b.title = "Open the wallet in a full browser tab";
      b.setAttribute("style","position:fixed;right:8px;bottom:8px;z-index:9999;font:12px system-ui;padding:4px 8px;border-radius:999px;border:1px solid rgba(128,128,128,.4);background:rgba(20,16,11,.85);color:#f5efe6;cursor:pointer");
      b.onclick = function(){ chrome.tabs.create({ url: chrome.runtime.getURL("index.html?tab=1") }); window.close(); };
      document.body.appendChild(b);
    }, 800);
  });
})();